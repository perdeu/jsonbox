<html>
<head>
	<script type="text/javascript" src="js/jquery-1.6.1.js"></script>
	<script type="text/javascript" src="js/jquery.jsonbox-1.0.0.js"></script>
	<script type="text/javascript" src="js/setup_combo.js"></script>
</head>
<body>
<form action="">
	Select a Country:
	<select id="country" name="country"> 
	</select>
	
	<br />
	
	Select a City:
	<select id="city" name="city"> 
	</select>
</form>
</body>
</html>